﻿using Volo.Abp.Localization;

namespace Sige.IoT.Admin.Localization
{
    [LocalizationResourceName("Admin")]
    public class AdminResource
    {

    }
}