﻿using System;

namespace Sige.IoT.Admin.Models.Test
{
    public class TestModel
    {
        public string Name { get; set; }

        public DateTime BirthDate { get; set; }
    }
}