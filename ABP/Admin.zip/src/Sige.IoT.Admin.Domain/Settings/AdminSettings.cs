﻿namespace Sige.IoT.Admin.Settings
{
    public static class AdminSettings
    {
        private const string Prefix = "Admin";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}