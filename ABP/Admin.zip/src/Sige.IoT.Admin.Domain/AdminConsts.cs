﻿namespace Sige.IoT.Admin
{
    public static class AdminConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
