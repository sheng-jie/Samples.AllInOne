﻿namespace Sige.IoT.Admin.Permissions
{
    public static class AdminPermissions
    {
        public const string GroupName = "Admin";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}