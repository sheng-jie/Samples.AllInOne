﻿module.exports = {
    aliases: {
        
    },
    mappings: {
        
    }
};
