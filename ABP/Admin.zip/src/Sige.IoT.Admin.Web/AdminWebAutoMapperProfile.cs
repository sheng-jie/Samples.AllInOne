﻿using AutoMapper;

namespace Sige.IoT.Admin.Web
{
    public class AdminWebAutoMapperProfile : Profile
    {
        public AdminWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
