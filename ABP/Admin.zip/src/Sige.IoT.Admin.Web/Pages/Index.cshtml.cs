﻿namespace Sige.IoT.Admin.Web.Pages
{
    public class IndexModel : AdminPageModel
    {
        public void OnGet()
        {
            
        }
    }
}