﻿namespace Sige.IoT.Admin
{
    public abstract class AdminApplicationTestBase : AdminTestBase<AdminApplicationTestModule> 
    {

    }
}
