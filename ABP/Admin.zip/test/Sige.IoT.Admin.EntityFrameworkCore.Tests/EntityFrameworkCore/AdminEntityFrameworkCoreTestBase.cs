﻿using Volo.Abp;

namespace Sige.IoT.Admin.EntityFrameworkCore
{
    public abstract class AdminEntityFrameworkCoreTestBase : AdminTestBase<AdminEntityFrameworkCoreTestModule> 
    {

    }
}
