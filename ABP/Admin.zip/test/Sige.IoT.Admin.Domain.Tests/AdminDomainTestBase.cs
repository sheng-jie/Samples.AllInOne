﻿namespace Sige.IoT.Admin
{
    public abstract class AdminDomainTestBase : AdminTestBase<AdminDomainTestModule> 
    {

    }
}
